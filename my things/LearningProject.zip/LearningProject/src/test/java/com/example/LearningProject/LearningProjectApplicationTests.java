package com.example.LearningProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
